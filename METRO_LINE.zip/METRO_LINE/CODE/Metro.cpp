#include<bits/stdc++.h>
using namespace std;

class DelhiMetroApp
{
public:
    // Structure to represent a metro station
    struct Station
    {
        string name;
        unordered_map<string, int> neighbors;
    };

    unordered_map<string, Station> metroMap;

public:

    // Function to add a new station to the metro map
    void addStation(const string& name)
    {
        Station newStation;
        newStation.name = name;
        metroMap[name] = newStation;
    }

    // Function to add a new metro line between two stations with travel time
    void addMetroLine(const string& station1, const string& station2, int time)
    {
        metroMap[station1].neighbors[station2] = time;
        metroMap[station2].neighbors[station1] = time;
    }

   void writeWelcomePageToFile()
    {
        ofstream welcomeFile("welcome_page.txt");

        if (welcomeFile.is_open())
        {

welcomeFile << "\n\n\n\n\n\n       __      __ ___  _      ___   ___   __  __  ___                 \n";
welcomeFile << "       \\ \\    / /| __|| |    / __| / _ \\ |  \\/  || __|                \n";
welcomeFile << "        \\ \\/\\/ / | _| | |__ | (__ | (_) || |\\/| || _|                 \n";
welcomeFile << "         \\_/\\_/  |___||____| \\___| \\___/ |_|  |_|___|                \n";
welcomeFile << "                                                                      \n";
welcomeFile << "                    _____   ___                                       \n";
welcomeFile << "                   |_   _| / _ \\                                      \n";
welcomeFile << "                     | |  | (_) |                                     \n";
welcomeFile << "                     |_|   \\___/                                      \n";
welcomeFile << "                                                                      \n";
welcomeFile << "                    ___   ___  _     _  _  ___                        \n";
welcomeFile << "                   |   \\ | __|| |   | || ||_ _|                       \n";
welcomeFile << "                   | |) || _| | |__ | __ | | |                        \n";
welcomeFile << "                   |___/ |___||____||_||_||___|                       \n";
welcomeFile << "                                                                      \n";
welcomeFile << "                     __  __  ___  _____  ___   ___                    \n";
welcomeFile << "                     |  \\/  || __||_   _|| _ \\ / _ \\                  \n";
welcomeFile << "                     | |\\/| || _|   | |  |   /| (_) |                 \n";
welcomeFile << "                     |_|  |_||___|  |_|  |_|_\\ \\___/                  \n";
welcomeFile << "                                                                      \n";
welcomeFile << " OO O o o o...      ______________________ _________________         \n";
welcomeFile << " O     ____          |                    | |               |         \n";
welcomeFile << " ][_n_i_| (   ooo___  |                    | |               |         \n";
welcomeFile << "(__________|_[______]_|____________________|_|_______________|         \n";
welcomeFile << " 0--0--0      0  0      0       0     0        0        0             \n";


            welcomeFile.close();
        }
        else
        {
            cerr << "Unable to open file for writing welcome page.\n";
        }
    }

    void displayWelcomePageFromFile()
    {
        ifstream welcomeFile("welcome_page.txt");

        if (welcomeFile.is_open())
        {
            string line;
            while (getline(welcomeFile, line))
            {
                cout << line << endl;
            }
            welcomeFile.close();
        }
        else
        {
            cerr << "Unable to open file for reading welcome page.\n";
        }
    }
    void writeWelcomePageToFile1()
    {
        ofstream welcomeFile("welcome_page1.txt");

        if (welcomeFile.is_open())
        {

welcomeFile << "       _____  _  _  ___  _  _  _  __                \n";
welcomeFile << "      |_   _|| || |/   \\| \\| || |/ /               \n";
welcomeFile << "        | |  | __ || - || .  ||   <                \n";
welcomeFile << "        |_|  |_||_||_|_||_\\_||_|\\_\\               \n";
welcomeFile << "      __   __  ___   _   _                       \n";
welcomeFile << "      \\ \\ / / / _ \\ | | | |                      \n";
welcomeFile << "       \\   / | (_) || |_| |                      \n";
welcomeFile << "        |_|   \\___/  \\___/                       \n";
welcomeFile << " ___   ___   ___                                \n";
welcomeFile << "| __| / _ \\ | _ \\                               \n";
welcomeFile << "| _| | (_) ||   /                               \n";
welcomeFile << "|_|   \\___/ |_|_\\                               \n";
welcomeFile << "__   __ ___  ___  ___  _____  ___  _  _   ___ \n";
welcomeFile << "\\ \\ / /|_ _|/ __||_ _||_   _||_ _|| \\| | / __|\n";
welcomeFile << " \\   /  | | \\__ \\ | |   | |   | | | .  || (_ |\n";
welcomeFile << "  \\_/  |___||___/|___|  |_|  |___||_|\\_| \\___|\n";



            welcomeFile.close();
        }
        else
        {
            cerr << "Unable to open file for writing welcome page.\n";
        }
    }

    void displayWelcomePageFromFile1()
    {
        ifstream welcomeFile("welcome_page1.txt");

        if (welcomeFile.is_open())
        {
            string line;
            while (getline(welcomeFile, line))
            {
                cout << line << endl;
            }
            welcomeFile.close();
        }
        else
        {
            cerr << "Unable to open file for reading welcome page.\n";
        }
    }

    void clearScreen() {

   #ifdef _WIN32
    system("cls");
   #else

    system("clear");
   #endif
  }

    // Function to find the shortest path between two stations using Dijkstra's algorithm
    vector<string> findShortestPath(const string& startStation, const string& endStation)
    {

        unordered_map<string, int> distance;
        unordered_map<string, string> previous;
        priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pq;

        for (const auto& entry : metroMap)
        {
            distance[entry.first] = INT_MAX;
        }

        distance[startStation] = 0;
        pq.push({0, startStation});

        while (!pq.empty())
        {
            string current = pq.top().second;
            int currentDistance = pq.top().first;
            pq.pop();

            if (currentDistance > distance[current])
            {
                continue;
            }

            for (const auto& neighbor : metroMap[current].neighbors)
            {
                int newDistance = currentDistance + neighbor.second;
                if (newDistance < distance[neighbor.first])
                {
                    distance[neighbor.first] = newDistance;
                    previous[neighbor.first] = current;
                    pq.push({newDistance, neighbor.first});
                }
            }
        }

        // Reconstruct the path
        vector<string> path;
        string current = endStation;
        while (!previous[current].empty())
        {
            path.push_back(current);
            current = previous[current];
        }
        path.push_back(startStation);

        reverse(path.begin(), path.end());
        return path;
    }
     // Calculate the fare
    double calculateFare(const vector<string>& path)
    {
        double totalFare = 0.0;


        const double baseFare = 20.0;
        const double farePerKilometer = 10.0;


        int totalDistance = 0;
        for (size_t i = 0; i< path.size() - 1; ++i)
        {
            totalDistance += metroMap[path[i]].neighbors[path[i + 1]];
        }


        totalFare = baseFare + farePerKilometer * totalDistance;


        if (totalFare < 100.0)
        {
            totalFare *= 0.9;
        }

        return ceil(totalFare);
    }

    void displayTravelTime(const vector<string>& path)
    {
        int totalTime = 0;


        for (size_t i = 0; i < path.size() - 1; ++i)
        {
            string currentStation = path[i];
            string nextStation = path[i + 1];
            totalTime += metroMap[currentStation].neighbors[nextStation];
        }

        cout << "Total Travel Time: " << totalTime << " minutes\n";
    }
};

void printColoredStation(const string& station, const string& color)
{
    cout << "\033[1;" << color << "m" << station << "\033[0m";
}

int getValidStationNumber(const string& prompt, const DelhiMetroApp& metroApp) {
    int stationNumber;
    stack<string> errorStack;

    do {
        cout << prompt;
        cin >> stationNumber;

        if (stationNumber < 1 || stationNumber > metroApp.metroMap.size()) {
            errorStack.push("Invalid input. Please choose a valid station number.");
        } else {
            return stationNumber;
        }

        cin.clear();


        while (!errorStack.empty()) {
            cerr << "Error: " << errorStack.top() << endl;
            errorStack.pop();
        }
    } while (true);
}

int main()
{
    DelhiMetroApp metroApp;
    metroApp.writeWelcomePageToFile();
    metroApp.displayWelcomePageFromFile();
    cout << "\nPress Enter to continue...";
    cin.get();
    metroApp.clearScreen();


    metroApp.addStation("Noida_Sector_62~B");
    metroApp.addStation("Botanical_Garden~B");
    metroApp.addStation("Yamuna_Bank~B");
    metroApp.addStation("Rajiv_Chowk~BY");
    metroApp.addStation("Vaishali~B");
    metroApp.addStation("Moti_Nagar~B");
    metroApp.addStation("Janak_Puri_West~BO");
    metroApp.addStation("Dwarka_Sector_21~B");
    metroApp.addStation("Huda_City_Center~Y");
    metroApp.addStation("Saket~Y");
    metroApp.addStation("Vishwavidyalaya~Y");
    metroApp.addStation("Chandni_Chowk~Y");
    metroApp.addStation("New_Delhi~YO");
    metroApp.addStation("AIIMS~Y");
    metroApp.addStation("Shivaji_Stadium~O");
    metroApp.addStation("DDS_Campus~O");
    metroApp.addStation("IGI_Airport~O");
    metroApp.addStation("Rajouri_Garden~BP");
    metroApp.addStation("Netaji_Subhash_Place~PR");
    metroApp.addStation("Punjabi_Bagh_West~P");



    metroApp.addMetroLine("Noida_Sector_62~B", "Botanical_Garden~B", 8);
    metroApp.addMetroLine("Botanical_Garden~B", "Yamuna_Bank~B", 10);
    metroApp.addMetroLine("Yamuna_Bank~B", "Vaishali~B", 8);
    metroApp.addMetroLine("Yamuna_Bank~B", "Rajiv_Chowk~BY", 6);
    metroApp.addMetroLine("Rajiv_Chowk~BY", "Moti_Nagar~B", 9);
    metroApp.addMetroLine("Moti_Nagar~B", "Janak_Puri_West~BO", 7);
    metroApp.addMetroLine("Janak_Puri West~BO", "Dwarka_Sector_21~B", 6);
    metroApp.addMetroLine("Huda_City_Center~Y", "Saket~Y", 15);
    metroApp.addMetroLine("Saket~Y", "AIIMS~Y", 6);
    metroApp.addMetroLine("AIIMS~Y", "Rajiv_Chowk~BY", 7);
    metroApp.addMetroLine("Rajiv_Chowk~BY", "New_Delhi~YO", 1);
    metroApp.addMetroLine("New_Delhi~YO", "Chandni_Chowk~Y", 2);
    metroApp.addMetroLine("Chandni_Chowk~Y", "Vishwavidyalaya~Y", 5);
    metroApp.addMetroLine("New_Delhi~YO", "Shivaji_Stadium~O", 2);
    metroApp.addMetroLine("Shivaji_Stadium~O", "DDS_Campus~O", 7);
    metroApp.addMetroLine("DDS_Campus~O", "IGI_Airport~O", 8);
    metroApp.addMetroLine("Moti_Nagar~B", "Rajouri_Garden~BP", 2);
    metroApp.addMetroLine("Punjabi_Bagh_West~P", "Rajouri_Garden~BP", 2);
    metroApp.addMetroLine("Punjabi_Bagh_West~P", "Netaji_Subhash_Place~PR", 3);

    cout << "********************************************\033[1;33mWELCOME TO DELHI METRO RAIL CORPORATION\033[0m******************************************" << endl;
    cout << "                                            ***************************************" << endl;

    cout << "\nList of Metro Stations:\n";
    int stationNumber = 1;
    for (const auto& entry : metroApp.metroMap)
    {
        cout << stationNumber << ". ";
        printColoredStation(entry.first, "32");
        cout << " ";
        cout << endl;
        stationNumber++;
    }
    cout << endl;

    int startStationNumber = getValidStationNumber("\nPlease enter the number corresponding to your START STATION:\n", metroApp);
    int endStationNumber = getValidStationNumber("\nPlease enter the number corresponding to your DESTINATION STATION:\n", metroApp);

    cout << "\nPress Enter to continue... ";
    cin.get();
    metroApp.clearScreen();

    string startStationName, endStationName;
    stationNumber = 1;
    for (const auto& entry : metroApp.metroMap)
    {
        if (stationNumber == startStationNumber)
        {
            startStationName = entry.first;
        }
        if (stationNumber == endStationNumber)
        {
            endStationName = entry.first;
        }
        stationNumber++;
    }

    cout << "\n\n\n\n\n\n\n\n\nCalculating the shortest path...\n";

    vector<string> shortestPath = metroApp.findShortestPath(startStationName, endStationName);

    cout << "\nShortest Path from ";
    printColoredStation(startStationName, "32");
    cout << " to ";
    printColoredStation(endStationName, "34");
    cout << ":\n";

    for (size_t i = 0; i < shortestPath.size(); ++i)
    {
        printColoredStation(shortestPath[i], "33");
        if (i < shortestPath.size() - 1)
        {
            cout << " -> ";
        }
    }
    cout << "\n";

    double fare = metroApp.calculateFare(shortestPath);
    cout << "\nTotal Fare: Rs" << fare << "\n";

    metroApp.displayTravelTime(shortestPath);
    cout<<endl;
    cout<<endl;
    cout<<endl;
    cout << "*************************************************************************************************************************" <<endl;

    metroApp.writeWelcomePageToFile1();
    metroApp.displayWelcomePageFromFile1();


    return 0;
}
